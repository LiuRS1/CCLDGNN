import torch
import torch.nn as nn
import numpy as np
import scipy.sparse as sp
import torch as th

def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = th.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = th.from_numpy(sparse_mx.data)
    shape = th.Size(sparse_mx.shape)
    return th.sparse.FloatTensor(indices, values, shape)

class Contrast(nn.Module):
    def __init__(self, hidden_dim, tau, lam):
        super(Contrast, self).__init__()
        self.proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ELU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        self.tau = tau
        self.lam = lam
        for model in self.proj:
            if isinstance(model, nn.Linear):
                nn.init.xavier_normal_(model.weight, gain=1.414)

    def sim(self, z1, z2):
        z1_norm = torch.norm(z1, dim=-1, keepdim=True)
        z2_norm = torch.norm(z2, dim=-1, keepdim=True)
        dot_numerator = torch.mm(z1, z2.t())
        dot_denominator = torch.mm(z1_norm, z2_norm.t())
        sim_matrix = torch.exp(dot_numerator / dot_denominator / self.tau)
        return sim_matrix

    def forward(self, z_mp, z_sc, pos ,s,t):
        z_proj_mp = self.proj(z_mp)
        z_proj_sc = self.proj(z_sc)
        matrix_mp2sc = self.sim(z_proj_mp, z_proj_sc)
        matrix_sc2mp = matrix_mp2sc.t()

        matrix_mp2sc = matrix_mp2sc / (torch.sum(matrix_mp2sc, dim=1).view(-1, 1) + 1e-8)

        # pos = np.vstack((pos.row, pos.col))
        # pos =  torch.sparse.LongTensor(pos)#pos =  torch.sparse.LongTensor(torch.tensor(pos))
        # pos = pos.todense()
        aa = sparse_mx_to_torch_sparse_tensor(pos).to_dense()
        # temp = aa[:64, :64]]
        temp = aa[s,t]
        lori_mp = -torch.log(matrix_mp2sc.mul(temp.cuda()).sum(dim=-1)+ 1e-8).mean()#temp = sparse_mx_to_torch_sparse_tensor(pos).to_dense

        matrix_sc2mp = matrix_sc2mp / (torch.sum(matrix_sc2mp, dim=1).view(-1, 1) + 1e-8)
        lori_sc = -torch.log(matrix_sc2mp.mul(temp.cuda()).sum(dim=-1)+ 1e-8).mean()
        # print()
        # print(lori_mp)
        # print(lori_sc)
        return self.lam * lori_mp + (1 - self.lam) * lori_sc

class Contrast1(nn.Module):
    def __init__(self, hidden_dim, tau, lam):
        super(Contrast1, self).__init__()
        self.proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ELU(),
            nn.Linear(hidden_dim, hidden_dim)
        )
        self.tau = tau
        self.lam = lam
        for model in self.proj:
            if isinstance(model, nn.Linear):
                nn.init.xavier_normal_(model.weight, gain=1.414)

    def sim(self, z1, z2):
        z1_norm = torch.norm(z1, dim=-1, keepdim=True)
        z2_norm = torch.norm(z2, dim=-1, keepdim=True)
        dot_numerator = torch.mm(z1, z2.t())
        dot_denominator = torch.mm(z1_norm, z2_norm.t())
        sim_matrix = torch.exp(dot_numerator / dot_denominator / self.tau)
        return sim_matrix

    def forward(self, z_mp, z_sc, poss ,s,t):
        z_proj_mp = self.proj(z_mp)
        z_proj_sc = self.proj(z_sc)
        matrix_mp2sc = self.sim(z_proj_mp, z_proj_sc)
        matrix_sc2mp = matrix_mp2sc.t()

        matrix_mp2sc = matrix_mp2sc / (torch.sum(matrix_mp2sc, dim=1).view(-1, 1) + 1e-8)

        # pos = np.vstack((pos.row, pos.col))
        # pos =  torch.sparse.LongTensor(pos)#pos =  torch.sparse.LongTensor(torch.tensor(pos))
        # pos = pos.todense()
        aa = sparse_mx_to_torch_sparse_tensor(poss).to_dense()
        # temp = aa[:64, :64]]
        temp = aa[s,t]
        lori_mp = -torch.log(matrix_mp2sc.mul(temp.cuda()).sum(dim=-1)+ 1e-8).mean()#temp = sparse_mx_to_torch_sparse_tensor(pos).to_dense

        matrix_sc2mp = matrix_sc2mp / (torch.sum(matrix_sc2mp, dim=1).view(-1, 1) + 1e-8)
        lori_sc = -torch.log(matrix_sc2mp.mul(temp.cuda()).sum(dim=-1)+ 1e-8).mean()
        # print()
        # print(lori_mp)
        # print(lori_sc)
        return self.lam * lori_mp + (1 - self.lam) * lori_sc
