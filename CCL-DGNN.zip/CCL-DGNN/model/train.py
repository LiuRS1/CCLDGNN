import torch
import numpy as np
from utils import *
from tqdm import tqdm
import psutil
from pos import *
import math
from sklearn.metrics import average_precision_score
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score
from eval import *
import time
import logging
logging.getLogger('matplotlib.font_manager').disabled = True
logging.getLogger('matplotlib.ticker').disabled = True

#
def train_val(train_val_data, model, mode, bs, epochs, criterion, optimizer, early_stopper, ngh_finders, rand_samplers, logger,tgan ,train_ngh_finder1,args,nn_val_src_l,nn_val_dst_l, nn_val_ts_l, nn_val_label_l,test_rand_sampler, test_src_l,test_dst_l, test_ts_l, test_label_l,nn_test_rand_sampler,nn_test_src_l,nn_test_dst_l, nn_test_ts_l, nn_test_label_l,Contrast):
    # unpack the data, prepare for the training
    train_data, val_data = train_val_data
    train_src_l, train_dst_l, train_ts_l, train_e_idx_l, train_label_l = train_data
    val_src_l, val_dst_l, val_ts_l, val_e_idx_l, val_label_l = val_data
    train_rand_sampler, val_rand_sampler = rand_samplers
    partial_ngh_finder, full_ngh_finder = ngh_finders
    if mode == 't':  # transductive
        model.update_ngh_finder(full_ngh_finder)
    elif mode == 'i':  # inductive
        model.update_ngh_finder(partial_ngh_finder)
    else:
        raise ValueError('training mode {} not found.'.format(mode))
    device = model.n_feat_th.data.device
    num_instance = len(train_src_l)
    num_batch = math.ceil(num_instance / bs)
    logger.info('num of training instances: {}'.format(num_instance))
    logger.info('num of batches per epoch: {}'.format(num_batch))
    idx_list = np.arange(num_instance)
    epoch_times = []
    for epoch in range(epochs):
        start_epoch = time.time()
        tgan.ngh_finder = train_ngh_finder1
        acc, ap, f1, auc, m_loss = [], [], [], [], []
        np.random.shuffle(idx_list)  # shuffle the training samples for every epoch
        logger.info('start {} epoch'.format(epoch))
        for k in tqdm(range(num_batch)):
            # generate training mini-batch
            s_idx = k * bs
            e_idx = min(num_instance - 1, s_idx + bs)
            if s_idx == e_idx:
                continue
            batch_idx = idx_list[s_idx:e_idx]
            src_l_cut, dst_l_cut = train_src_l[batch_idx], train_dst_l[batch_idx]
            ts_l_cut = train_ts_l[batch_idx]
            e_l_cut = train_e_idx_l[batch_idx]
            label_l_cut = train_label_l[batch_idx]  # currently useless since we are not predicting edge labels
            size = len(src_l_cut)
            src_l_fake, dst_l_fake = train_rand_sampler.sample(size)

            # feed in the data and learn from error
            optimizer.zero_grad()
            model = model.train()
            # tgan = tgan.train()
            pos_prob, neg_prob, src_embed, tgt_embed = model.contrast(src_l_cut, dst_l_cut, dst_l_fake, ts_l_cut, e_l_cut)   # the core training code
            # pos_prob1, neg_prob1 , source_embed, target_embed = tgan.contrast(src_l_cut, dst_l_cut, dst_l_fake, ts_l_cut, args.SEQ_LEN)
            # loss_compara1 = Contrast(src_embed, source_embed, pos,src_l_cut,dst_l_cut)
            # loss_compara2 = Contrast(tgt_embed, target_embed, pos,src_l_cut,dst_l_cut)
            # print()


            pos_label = torch.ones(size, dtype=torch.float, device=device, requires_grad=False)
            neg_label = torch.zeros(size, dtype=torch.float, device=device, requires_grad=False)
            # print(loss_compara1)
            # print(loss_compara2)
            loss1 =  criterion(pos_prob, pos_label) + criterion(neg_prob, neg_label)
            # loss2 = criterion(pos_prob1, pos_label) + criterion(neg_prob1, neg_label)
            # loss3 = loss_compara1.item() + loss_compara2.item()
            loss =  loss1  #+ 0.01*loss3 #+ loss2
            loss.backward()
            #loss1.backward()
            optimizer.step()

            # collect training results
            with torch.no_grad():
                model.eval()
                tgan = tgan.eval()
                pred_score = np.concatenate([pos_prob.cpu().detach().numpy(), neg_prob.cpu().detach().numpy()])
                pred_label = pred_score > 0.5
                true_label = np.concatenate([np.ones(size), np.zeros(size)])
                acc.append((pred_label == true_label).mean())
                ap.append(average_precision_score(true_label, pred_score))
                f1.append(f1_score(true_label, pred_label))
                m_loss.append(loss.item())
                auc.append(roc_auc_score(true_label, pred_score))

        epoch_time = time.time() - start_epoch
        epoch_times.append(epoch_time)
        print(epoch_times)
        # validation phase use all information
        val_acc, val_ap, val_f1, val_auc = eval_one_epoch('val for {} nodes'.format(mode), model, val_rand_sampler, val_src_l,
                                                          val_dst_l, val_ts_l, val_label_l, val_e_idx_l)
        logger.info('epoch: {}:'.format(epoch))

        logger.info('epoch mean loss: {}'.format(np.mean(m_loss)))
        logger.info('train acc: {}, val acc: {}'.format(np.mean(acc), val_acc))
        logger.info('train auc: {}, val auc: {}'.format(np.mean(auc), val_auc))
        logger.info('train ap: {}, val ap: {}'.format(np.mean(ap), val_ap))
        if epoch == 0:
            # save things for data anaysis
            checkpoint_dir = '/'.join(model.get_checkpoint_path(0).split('/')[:-1])
            model.ngh_finder.save_ngh_stats(checkpoint_dir)  # for data analysis
            model.save_common_node_percentages(checkpoint_dir)

        # early stop check and checkpoint saving
        if early_stopper.early_stop_check(val_ap):
            logger.info('No improvment over {} epochs, stop training'.format(early_stopper.max_round))
            logger.info(f'Loading the best model at epoch {early_stopper.best_epoch}')
            best_checkpoint_path = model.get_checkpoint_path(early_stopper.best_epoch)
            model.load_state_dict(torch.load(best_checkpoint_path))
            logger.info(f'Loaded the best model at epoch {early_stopper.best_epoch} for inference')
            model.eval()
            break
        else:
            torch.save(model.state_dict(), model.get_checkpoint_path(epoch))

    #
    #     tgan.ngh_finder = full_ngh_finder
    #     val_acc, val_ap, val_f1, val_auc = eval_one_epoch1('val for old nodes', tgan, val_rand_sampler, val_src_l,
    #                                                       val_dst_l, val_ts_l, val_label_l , args)
    #
    #     nn_val_acc, nn_val_ap, nn_val_f1, nn_val_auc = eval_one_epoch1('val for new nodes', tgan, val_rand_sampler,
    #                                                                   nn_val_src_l,
    #                                                                   nn_val_dst_l, nn_val_ts_l, nn_val_label_l,args)
    #
    #     logger.info('epoch: {}:'.format(epoch))
    #     logger.info('Epoch mean loss: {}'.format(np.mean(m_loss)))
    #     logger.info('train acc: {}, val acc: {}, new node val acc: {}'.format(np.mean(acc), val_acc, nn_val_acc))
    #     logger.info('train auc: {}, val auc: {}, new node val auc: {}'.format(np.mean(auc), val_auc, nn_val_auc))
    #     logger.info('train ap: {}, val ap: {}, new node val ap: {}'.format(np.mean(ap), val_ap, nn_val_ap))
    #     # logger.info('train f1: {}, val f1: {}, new node val f1: {}'.format(np.mean(f1), val_f1, nn_val_f1))
    #     print(u'当前进程的内存使用:%.4f GB' % (psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024 / 1024))
    #     MODEL_SAVE_PATH = f'./saved_models/{args.prefix}-{args.attn_agg_method}-{args.attn_mode}-{args.data}.pth'
    #     get_checkpoint_path = lambda epoch: f'./saved_checkpoints/{args.prefix}-{args.attn_agg_method}-{args.attn_mode}-{args.data}-{epoch}.pth'
    #     if early_stopper.early_stop_check(val_ap):
    #         logger.info('No improvment over {} epochs, stop training'.format(early_stopper.max_round))
    #         logger.info(f'Loading the best model at epoch {early_stopper.best_epoch}')
    #         best_model_path = get_checkpoint_path(early_stopper.best_epoch)
    #         tgan.load_state_dict(torch.load(best_model_path))
    #         logger.info(f'Loaded the best model at epoch {early_stopper.best_epoch} for inference')
    #         tgan.eval()
    #         break
    #     else:
    #         torch.save(tgan.state_dict(), get_checkpoint_path(epoch))
    # tgan.ngh_finder = full_ngh_finder
    # test_acc, test_ap, test_f1, test_auc = eval_one_epoch1('test for old nodes', tgan, test_rand_sampler, test_src_l,
    #                                                       test_dst_l, test_ts_l, test_label_l,args)
    #
    # nn_test_acc, nn_test_ap, nn_test_f1, nn_test_auc = eval_one_epoch1('test for new nodes', tgan, nn_test_rand_sampler,
    #                                                                   nn_test_src_l,
    #                                                                   nn_test_dst_l, nn_test_ts_l, nn_test_label_l,args)
    #
    # logger.info('Test statistics: Old nodes -- acc: {}, auc: {}, ap: {}'.format(test_acc, test_auc, test_ap))
    # logger.info('Test statistics: New nodes -- acc: {}, auc: {}, ap: {}'.format(nn_test_acc, nn_test_auc, nn_test_ap))
    #
    # logger.info('Saving TGAN model')
    # torch.save(tgan.state_dict(), MODEL_SAVE_PATH)
    # logger.info('TGAN models saved')




