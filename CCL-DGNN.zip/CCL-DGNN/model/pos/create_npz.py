from tqdm import tqdm
import pandas as pd
import numpy as np
import argparse
import sys

import scipy.sparse as sp

from scipy.sparse import csr_matrix


def preprocess(data_name):
    u_list, i_list = [], []
    idx_list = []

    with open(data_name) as f:
        s = next(f)
        print(s)
        for idx, line in tqdm(enumerate(f)):
            e = line.strip().split(',')
            u = int(e[0])
            i = int(e[1])

            u_list.append(u)
            i_list.append(i)

    return pd.DataFrame({'u': u_list,
                         'i': i_list,
                         })


def reindex(df, jodie_data):
    if jodie_data:
        upper_u = df.u.max() + 1
        new_i = df.i + upper_u
        upper_i = df.i.max() + upper_u

        new_df = df.copy()
        new_df.i = new_i

        new_df.u += 1
        new_df.i += 1

    else:
        new_df = df.copy()
        new_df.u += 1
        new_df.i += 1

    return new_df, upper_u, upper_i


def run(args):
    data_name = args.dataset
    PATH = './processed/{}.csv'.format(data_name)

    jodie_data = data_name in ['mooc', 'uci', 'reddit', 'wikipedia', 'enron', 'socialevolve','ml_blockchain']
    print('preprocess {} dataset ...')
    df = preprocess(PATH)
    new_df, upper_u, upper_i = reindex(df, jodie_data)
    nmp = new_df.to_numpy()
    np.savetxt('./pos/wikipedia_pa.txt', nmp, fmt='%d')
    P = upper_u + 1
    A = upper_i + P
    pa = np.genfromtxt("./pos/wikipedia_pa.txt")

    pa_ = sp.coo_matrix((np.ones(pa.shape[0]), (pa[:, 0], pa[:, 1])), shape=(P, A)).toarray()

    apa = np.matmul(pa_.T, pa_) > 0
    pap = np.matmul(pa_, pa_.T) > 0
    apa = sp.coo_matrix(apa)
    pap = sp.coo_matrix(pap)
    a = pap.todense()
    print(a)
    sp.save_npz("./pos/wikipedia_apa.npz", apa)
    sp.save_npz("./pos/wikipedia_pap.npz", pap)

    # nn = sp.coo_matrix(nmp)
    # print(nn)
    # np.savez(pap,nn)
    # pap = sp.load_npz("D:/My_code1/code/model/pos/apa.npz")
    # print(pap)


parser = argparse.ArgumentParser('Interface for propressing csv source data for TGAT framework')
parser.add_argument('--dataset',
                    choices=['mooc', 'reddit', 'socialevolve', 'uci', 'socialevolve_1month', 'enron',
                             'blockchain','wikipedia'],
                    help='specify one dataset to preprocess', default='wikipedia')

try:
    args = parser.parse_args()
except:
    parser.print_help()
    sys.exit(0)

run(args)